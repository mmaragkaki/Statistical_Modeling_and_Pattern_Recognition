function [Z] = projectDataLDA(X, v)

% You need to return the following variables correctly.
Z = zeros(size(X, 1), 1);

% ====================== YOUR CODE HERE ======================
Z = X*v;
%Z = v.'*X.';
% =============================================================

end
