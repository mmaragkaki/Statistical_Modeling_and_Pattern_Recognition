function Z = projectData(X, U, K)
%PROJECTDATA Computes the reduced data representation when projecting only 
%on to the top k eigenvectors
%   Z = projectData(X, U, K) computes the projection of 
%   the input samples X into the reduced dimensional space spanned by
%   the first K columns of U. It returns the projected examples in Z.
%

% You need to return the following variables correctly.
Z = zeros(size(X, 1), K);

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the projection of the data using only the top K 
%               eigenvectors in U (first K columns). 
%

% rows = size(X,1);
% for i=1:rows
%     Z(i,1) = Utrans(1,1)*X(i,1) + Utrans(1,2)*X(i,2);
% end
Z = X*U(:,(1:K));
% =============================================================

end
