clear; close all; clc
data_file = './data/mnist.mat';

data = load(data_file);

images = zeros(size(data.trainX, 1), 28, 28);
labels = zeros(size(data.trainY,2), 1);

for i = 1:size(data.trainX, 1)
    img = data.trainX(i, :);
    images(i, :, :) = reshape(img, 28, 28)';
    labels(i) = data.trainY(i);
end

digit_C1_indices = find(labels == 1); % digit 1
digit_C2_indices = find(labels == 2); % digit 2

digit_C1_images = images(digit_C1_indices, :, :);
digit_C2_images = images(digit_C2_indices, :, :);
% imagesc(reshape(digit_C1_images(1,:,:),28,28));
% colormap(gray);

num = size(digit_C1_images,1) + size(digit_C2_images,1);
aRatios = zeros(num, 1); 

% Compute the aspect ratios of all images and store the value of the i-th
% image in aRatios(i)

for i=1:num
    if i<=size(digit_C1_images,1)
        aRatios(i) = computeAspectRatio(digit_C1_images(i,:,:));
    else
        j=i-size(digit_C1_images,1);
        aRatios(i) = computeAspectRatio(digit_C2_images(j,:,:));
    end
end


minAspectRatio = min(aRatios);
maxAspectRatio = max(aRatios);

a1 = minAspectRatio + (maxAspectRatio - minAspectRatio)/3;
a2 = minAspectRatio + (2*(maxAspectRatio - minAspectRatio))/3;

DT=0.01;
Low= minAspectRatio:DT:a1;
Medium= a1:DT:a2;
Hight= a2:DT:maxAspectRatio;

numBins = 3;

binEnds = linspace(minAspectRatio, maxAspectRatio, numBins+1);
index_C1=zeros(size(digit_C1_images,1),1);
index_C2=zeros(size(digit_C2_images,1),1);
C1_bins = zeros(numBins, 1);
C2_bins = zeros(numBins, 1);
all_bins = zeros(numBins, 1);
% Use the findBin function to get the counts for the histogram
for i=1:num
    if i<=size(digit_C1_images,1)
        index_C1(i) = findBin(aRatios(i),binEnds);
        C1_bins(index_C1(i),1) = C1_bins(index_C1(i),1) + 1;
        
    else
        j=i-size(digit_C1_images,1);
        index_C2(j) = findBin(aRatios(i),binEnds);
        C2_bins(index_C2(j),1) = C2_bins(index_C2(j),1) + 1; 

    end
    
end

C1=categorical(index_C1,[1 2 3],{'Low','Medium','High'});
figure;
h1 = histogram(C1,'BarWidth',0.5);
title('Histogram of C1', 'FontSize', 12);
C2=categorical(index_C2,[1 2 3],{'Low','Medium','High'});
figure;
h2 = histogram(C2,'BarWidth',0.5);
title('Histogram of C2', 'FontSize', 12);

% Prior Probabilities
PC1 = size(digit_C1_images,1)/(size(digit_C1_images,1)+size(digit_C2_images,1))
PC2 = size(digit_C2_images,1)/(size(digit_C1_images,1)+size(digit_C2_images,1))
% Likelihoods
PLgivenC1 = (C1_bins(1,1)/size(index_C1,1))*PC1
PMgivenC1 = (C1_bins(2,1)/size(index_C1,1))*PC1
PHgivenC1 = (C1_bins(3,1)/size(index_C1,1))*PC1

PLgivenC2 = (C2_bins(1,1)/size(index_C2,1))*PC2
PMgivenC2 = (C2_bins(2,1)/size(index_C2,1))*PC2
PHgivenC2 = (C2_bins(3,1)/size(index_C2,1))*PC2

PL = (C1_bins(1,1)+C2_bins(1,1))/(size(index_C1,1)+size(index_C2,1))
PM = (C1_bins(2,1)+C2_bins(2,1))/(size(index_C1,1)+size(index_C2,1))
PH = (C1_bins(3,1)+C2_bins(3,1))/(size(index_C1,1)+size(index_C2,1))
% Evidence  

% Posterior Probabilities
PC1givenL = (PLgivenC1*PC1)/PL
PC2givenL = (PLgivenC2*PC2)/PL