function index = findBin(value, binEnds)
    numBins = length(binEnds) - 1;
    % return the index of the bin where value belongs {1, ..., numBins}.
    
    if (value>=binEnds(1)) && (value<=binEnds(2))
        index = numBins-2;
    elseif (value>binEnds(2)) && (value<=binEnds(3))
        index = numBins-1;
    else
        index = numBins;
    end
    
end