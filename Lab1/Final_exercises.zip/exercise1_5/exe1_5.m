clear; close all; clc

P1=[0.1 0.25 0.5 0.75 0.9];
P2=[0.9 0.75 0.5 0.25 0.1];
num = size(P1,2)
for i=1:num
    syms x y
    x=(log(P1(i))-log(P2(i))-0.03*y+11.43)/(0.62*y+0.03);
    %x=(log(P1(i))-log(P2(i))-1.89*y+17.01)/1.89;
    %0.03*x+0.03*y++0.62*x*y-11.43-log(P1(i))+log(P2(i))==0
    ezplot(x,[-4 10 -4 12]);
    hndl=get(gca,'Children');
    set(hndl,'LineWidth',1.5,'Color',[0 0 0]);
    grid on;
    title('x_1=(ln(p1)-ln(p2)-0.03x_2+11.43)/(0.62*x_2+0.03)')
    hold on ;
end
    line([0 0], [-4 12],'LineWidth',1,'Color','black','LineStyle','--')
    line([-4 10], [0 0],'LineWidth',1,'Color','black','LineStyle','--')
    str1 = '\omega_1'
    text(4.5,8,str1,'Fontsize',15)
    str1 = '\omega_2'
    text(3.5,-1,str1,'Fontsize',15)
    str1 = '\rightarrow boundary'
    text(2.5,9,str1,'Fontsize',12)
DT=0.01;
%% Draw the gaussians (likelihoods)
x1=[-4:DT:12]; %Horizontal axis
x2=[-4:DT:12];
[X1,X2]=meshgrid(x1,x2);
mu1 = [3 3];
mu2=[6 6];
SIGMA1 = [1.2 -0.4; -0.4 1.2];
SIGMA2 = [1.2 0.4; 0.4 1.2];
hold on;
Y1=mvnpdf([X1(:) X2(:)],mu1,SIGMA1);
Y1R=reshape(Y1,length(x2),length(x1));
Y2=mvnpdf([X1(:) X2(:)],mu2,SIGMA2);
Y2R=reshape(Y2,length(x2),length(x1));
contour(x1,x2,Y1R,[.0001 .001 .01 .05:.1:.95 .99 .999 .9999],'LineColor','r')
contour(x1,x2,Y2R,[.0001 .001 .01 .05:.1:.95 .99 .999 .9999],'LineColor','b')
grid on

