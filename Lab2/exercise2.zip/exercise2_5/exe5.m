clear all; close all; clc

H = load('data_2_5.txt');
n = size(H,1);
sigma = 1.25;
mu = mean(H);
%%%%%%%%% Part 1 %%%%%%%%

y = normpdf(H,mu,sigma^2);
mu0 = 0;
sigma0 = sqrt(10*(sigma^2)) ;
y1 = normpdf(H,mu0,sigma0^2);
figure;
sumH = 0
mu_n = zeros(1,25);
H_n = zeros(25,1);
sigma_n = zeros(1,25);
theta = linspace(-2,10,500);

for j=1:n
    H_n(j,:) = mean(H(1:j,1));
end
for i=1:n
    mu_n(:,i) = (i*sigma0^2*H_n(i,:) + sigma^2*mu0)/(i*sigma0^2 + sigma^2);
    sigma_n(:,i) = sqrt((sigma^2*sigma0^2)/(i*sigma0^2+sigma^2));
    y2 = normpdf(theta,mu_n(:,i),sigma_n(:,i));
    hold on
    plot(theta,y2)
    xlabel('m')
    ylabel('P(m|H(n))')
    hold off
end
figure;
theta1 = linspace(-20,20,500);
sigma0 = sqrt(0.01*(sigma^2)) ;
mu_n = (n*sigma0^2 + sigma^2*mu0)/(i*sigma0^2 + sigma^2);
sigma_n = sqrt((sigma^2*sigma0^2)/(i*sigma0^2+sigma^2));
sigma_new = sqrt(sigma0^2 + sigma_n^2);
y3 = normpdf(theta1,mu_n,sigma_new);
hold on
plot(theta1,y3)
xlabel('x')
ylabel('P(x|H(n))')
title('sigma0^2=0.01*sigma^2')
hold off



