clear 
close all
clc
% C = 10000; % Choose C = 0.01, 0.1, 1, 10, 100, 1000, 10000

load('./twofeature1.txt');
n = size(twofeature1, 1) - 1; % leave out the last example
y = twofeature1(1:n, 1);
X = twofeature1(1:n, 2:3);
Xpos = X(y==1, :); % positive examples
Xneg = X(y==-1, :); % negative examples

%  Visualize the example dataset
hold on
plot(Xpos(:, 1), Xpos(:, 2), 'b.');
plot(Xneg(:, 1), Xneg(:, 2), 'r.');
hold off
axis square;

% Form the matrices for the quadratic optimization. See the matlab manual for "quadprog"
 H = zeros(n,n);
 for i=1:n
     for j=1:n
         H(i,j) = y(i)*y(j)*X(i,:)*X(j,:)';
     end
 end
f = -ones(n,1);
A = -ones(1,n);
b = 0;
Aeq=y';
beq = 0;
lb=zeros(n,1);
ub=5*ones(n,1);
lambda = quadprog(H,f,A,b,Aeq,beq,lb,ub); % Find the Lagrange multipliers

indices = find(lambda > 0.0001); % Find the support vectors
Xsup = zeros(size(indices,1),2);
ysup = zeros(size(indices));
lambdasup = zeros(size(indices));
% The support vectors only

for i=1:size(indices,1)
    Xsup(i,:) = X(indices(i),:);
    ysup(i) =  y(indices(i));
    lambdasup(i) = lambda(indices(i));
end

% Find the weights

w = sum(Xsup.*ysup.*lambdasup);

% Find the bias term w0
w0 = mean(ysup(1)-Xsup(1,:)*w');

% Plot support vectors
Xsup_pos = Xsup(ysup==1, :);
Xsup_neg = Xsup(ysup==-1, :);

hold on
plot(Xsup_pos(:, 1), Xsup_pos(:, 2), 'bo');
plot(Xsup_neg(:, 1), Xsup_neg(:, 2), 'ro');
hold off
% Find the width of the margin
width = 2/norm(w);
% Plot decision boundary
x1min = min(X(:,1));
x1max = max(X(:,1));
x2min = min(X(:,2));
x2max = max(X(:,2));
x1 = linspace(0.5, 4.5, 100);
x2 = -(w(1).*x1 + w0)./w(2);
hold on
Line1=@(x1,x2) w(1)*x1+w(2)*x2+w0;
LineA=@(x1,x2) w(1)*x1+w(2)*x2+w0+1;
LineB=@(x1,x2) w(1)*x1+w(2)*x2+w0-1;
handleA = ezplot(LineA,[x1min x1max x2min x2max]);
set(handleA,'Color','k','LineWidth',1,'LineStyle',':');
handleB = ezplot(LineB,[x1min x1max x2min x2max]);
set(handleB,'Color','k','LineWidth',1,'LineStyle',':');
handle = ezplot(Line1,[x1min x1max x2min x2max]);
set(handle,'Color','k','LineWidth',2);
hold off


