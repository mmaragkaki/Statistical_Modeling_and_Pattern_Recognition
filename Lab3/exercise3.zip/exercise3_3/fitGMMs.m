function [Pc_old, Mu_old, Cov_old] = fitGMMs(X, K)
    %
    % INPUT:
    %   X: (N X d) N example vectors of dimension d
    %   K: number of GMM components
    %
    % OUTPUT:
    %   Pm: (K X 1) mixing probabilities
    %   M: (K X d) mean vectors
    %   S: (K X d X d) covariance matrices      
    [N, d] = size(X);

    % Initialize using kmeans. You may use the matlab kmeans.

    % your code here
    [c,Cent] = kmeans(X,K);
    InitPc = zeros(K,1);
    InitMu = zeros(K,d);
    InitCov = zeros(d,d,K);
    for k=1:K
        c_idx = find(c == k);
        InitPc(k) = length(c_idx)/N;
        InitMu(k,:) = Cent(k,:);
        InitCov(:,:,k) = cov(X(c_idx,:));
    end
    G = zeros(N, K); % likelihood of classes given features
    Pc_old = InitPc;
    Mu_old = InitMu;
    Cov_old = InitCov;
    Pc_new = zeros(size(Pc_old));
    Mu_new = zeros(size(Mu_old));
    Cov_new = zeros(size(Cov_old));
    for its = 1:100
        % E-step. Calculation of likelihood 'G'
        % your code here
        for i=1:N
            for j=1:K
                 G(i,j) = Pc_old(j)*gaussian(X(i,:),Mu_old(j,:),Cov_old(:,:,j));
            end
        end
        % Likelihood normalization (of G)
        % your code here 
        sumG = sum(G,2);
        for i=1:N
            for j=1:K
                tmp = G(i,j)/sumG(i);
                G(i,j) = tmp;
            end
        end
        % M-step. Parameter updates
        % your code here
        N_k = sum(G);
        for i=1:K
            final = 0;
            for j=1:N
                mult = G(j,i)*X(j,:);
                tmp = final;
                final = tmp + mult;
            end
            Mu_new(i,:) = final/N_k(i);
            
            final = 0;
            for k=1:N
                M = X(k,:)- Mu_new(i,:);
                mult = G(k,i)*(M.'*M);
                tmp = final;
                final = tmp + mult;
            end
            Cov_new(:,:,i) = final/N_k(i);
            Pc_new(i) = N_k(i)/N;          
        end
        Pc_old = Pc_new;
        Mu_old = Mu_new;
        Cov_old = Cov_new;       
    end 
