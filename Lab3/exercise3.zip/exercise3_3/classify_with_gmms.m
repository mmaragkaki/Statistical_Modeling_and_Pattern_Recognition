function y = classify_with_gmms(x, Pm, M, S)
    %
    % INPUT:
    %   x: (1 X d) An example vector of dimension d
    %   Pm: (K X 1) mixing probabilities
    %   M: (K X d) mean vectors
    %   S: (K X d X d) covariance matrices
    %
    % OUTPUT:
    %   y:  The class index  
    % your code here
    
    prob_c1 = Pm(1)*gaussian(x,M(1,:),S(:,:,1));
    prob_c2 = Pm(2)*gaussian(x,M(2,:),S(:,:,2));
    prob_c3 = Pm(3)*gaussian(x,M(3,:),S(:,:,3));
    
    if prob_c1>prob_c2 
        
        if prob_c1>prob_c3
            y = 1;
        else
            y = 3;
        end
    else
       
        if prob_c2>prob_c3
            y = 2;
        else
            y = 3;
        end
    end
        
