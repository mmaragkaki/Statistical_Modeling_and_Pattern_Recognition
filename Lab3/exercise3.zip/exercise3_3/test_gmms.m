clear all;
clc
load fisheriris.mat

X = meas;
N = size(X, 1); % number of examples
species

K = 3; % Number of classes

[Pm, M, S] = fitGMMs(X, K);

Y_hat = zeros(N, 1);
countY = cell(N,1);
for i = 1:N
    Y_hat(i, 1) = classify_with_gmms(X(i, :), Pm, M, S);
    if Y_hat(i, 1) == 1
        countY{i,1} = 'setosa';
    elseif Y_hat(i, 1) == 2
        countY{i,1} = 'versicolor';
    else
        countY{i,1} = 'virginica';
    end
end
wrong = 0;
for i=1:N
    comp = strcmp(countY{i},species{i});
    if comp == 0
        wrong = wrong + 1;
    end
end
Y_hat
Acc=(N-wrong)*100/N ;
out=sprintf('Accuracy: %f',Acc);
disp(out)
