function [test_z] = KNN_classify(k, train_f, train_y, test_f, dtype)
   % K-NN classification algorithm
   % k: Number of nearest neighbours
   % train_f: The matrix of training feature vectors
   % train_y: The labels of the training data
   % test_f: The matrix of the test feature vectors
   % dtype: Integer which defines the distance metric
   %    dtype=1: Call the function Euclidean_Distance
   %    dtype=2: Call the function CosineSimilarity_Distance
 
   % Add your code here
   label = zeros(size(test_f,1),1);
   for i=1:size(test_f,1)
       if dtype==1
           test_f_new = repmat(test_f(i,:),size(train_f,1),1);
            dists = Euclidean_Distance(test_f_new,train_f);
            [~,I]=sort(dists);
       else
            test_f_new = repmat(test_f(i,:),size(train_f,1),1);
            dists = CosineSimilarity_Distance(test_f_new,train_f);
            [~,I]=sort(dists,'descend');
       end
       nearest = train_y(I(1:k));
       c = zeros(4,1);
       for l=1:size(nearest,1)
            if nearest(l) == 1
                tmp = c(1) +1;
                c(1) = tmp;
            elseif nearest(l) == 2
                tmp = c(2) +1;
                c(2) = tmp;
            elseif nearest(l) == 3
                tmp = c(3) +1;
                c(3) = tmp;
            else
                tmp = c(4) +1;
                c(4) = tmp;
            end
       end
       [~,Z] = sort(c,'descend');
       label(i) = Z(1);
       
   end
    test_z = label;
end
   
 
