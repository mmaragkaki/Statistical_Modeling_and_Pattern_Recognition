function [dists] = Euclidean_Distance(testX, trainX)
%     Compute the Euclidean  distance between the 
%     current test sample and all training samples
%
% 	  testX: a single feature vector (test)
% 	  trainX: a matrix containing the set of training samples
%     dists: vector of the distances from the training samples

%  ADD your code here
        dists = sum((testX-trainX).^2,2);
%         dists = zeros(size(testX,1),1);
%         for i=1:size(testX,1)
%             for j=1:size(testX,2)
%                 tmp = dists(i) + (testX(i,j) - trainX(i,j))^2;
%                 dists(i) = tmp;
%             end
%         end
end