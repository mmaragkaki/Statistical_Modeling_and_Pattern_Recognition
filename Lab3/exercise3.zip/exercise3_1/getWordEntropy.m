function [e]=getWordEntropy(f)
    %Calculate the vector of word entropies e 
    %from the Term Frequency matrix f
    %Add your code here

    [nD,nT] = size(f);
    p = zeros(nD,nT);
    mult =  zeros(nD,nT);
    e_tmp = zeros(1,nT);
    for i=1:nD
        for j=1:nT
            if f(i,j) == 0
                f(i,j) = 0.00001;
            end
        end
    end
    for i=1:nD
        for j=1:nT
            p(i,j) = f(i,j)/sum(f(:,j));
            mult(i,j) = p(i,j)*log(p(i,j));
        end
    end
    
    for j=1:nT
        e_tmp(j)= -sum(mult(:,j))/log(nD);
    end
    e = e_tmp;
end