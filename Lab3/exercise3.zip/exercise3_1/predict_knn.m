function [label,accuracy] = predict_knn(X,Y,Xnew,k,Ynew)
     load fisheriris
X = meas;
    Y = species;
    Xnew = [min(meas);mean(meas);max(meas)];
    k = 5;
    [C,~,Y] = unique(Y,'stable');
    P = size(Xnew,1);
    label = zeros(P,1);
    for i = 1:P
        % Euclidean distance between two points
        A = repmat(Xnew(i,:),size(X,1),1)-X;
        distances = sqrt(sum(A.^2,2));
        % Sort the distances in ascending order and check the k nearest training labels
        [~,I] = sort(distances);
        Ynearest = Y(I(1:k));
        % Frequencies of the k nearest training labels
        N = histc(Ynearest,1:max(Ynearest));
        frequencies = N(Ynearest);
        % Nearest training label with maximum frequency (if duplicated, check the nearest training instance)
        [~,J] = max(frequencies);
        label(i) = Ynearest(J);
    end
    label = C(label);
    % Check the number of input and output arguments
    if nargin > 4 && nargout > 1
        [~,Ynew] = ismember(Ynew,C);
        accuracy = sum(label==Ynew)/P;
    end
    
end