function dists = CosineSimilarity_Distance(testX, trainX)
%     Compute the Cosine Similarity distance between the 
%     current test sample and all training samples
%
% 	  testX: a single feature vector (test)
% 	  trainX: a matrix containing the set of training samples
%     dists: vector of the distances from the training samples

% ADD your code here
        dists = sum(testX.*trainX,2)./(sqrt(sum(testX.^2,2)).*sqrt(sum(trainX.^2,2)));
%         sumxy = 0;
%         sumx = 0;
%         sumy = 0;
%         for i=1:size(trainX,2)
%             tmp1 = sumxy + (testX(:,i).*trainX(:,i));
%             sumxy = tmp1;
%             tmp2 = sumx + testX(:,i).^2;
%             sumx = tmp2;
%             tmp3 = sumy + trainX(:,i).^2;
%             sumy = tmp3;
%         end
%         dists = sumxy./((sqrt(sumx)).*(sqrt(sumy)));

end
