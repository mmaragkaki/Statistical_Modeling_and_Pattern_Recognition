function [newVocabulary, newTermEntropy, new_f] = GetNewVocabulary(r, Vocabulary, e, f)
    %Return the top r words in the Vocabulary (newVocabulary) 
    %    based on their entropy value
    %Also return 
    %   newTermEntropy: their corresponding Entropy value
    %   new_f: the new Term Document Matrix based on the
    %                newVocabulary

    % ADD Your Code Here
    [B,I] = sort(e);
    newTermEntropy = B(1,1:r);
    newVocabulary = Vocabulary(I(1:r),:);
    new_f = f(:,I(1:r)); 
end